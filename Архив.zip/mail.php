<?php
echo 'ок';